import App from './App.jsx'
import React from 'react'
import ReactDOM from 'react-dom'
import ChessBoard from './App.jsx'
// import ChessBoard from './ChessBoard'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
    <ChessBoard />
  </StrictMode>,
)
