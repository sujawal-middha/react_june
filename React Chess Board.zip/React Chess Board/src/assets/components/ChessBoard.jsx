// import React, { useState } from 'react'
// // import './App.css'

// const ChessBoard = () => {
//   const board=[];


// for(let row=0; row< 8; row++) {
//   const squares=[];                
//   for(let col=0; col<8; col++) {
//     const blackSq = (row+col)%2=== 1;  
//   squares.push(
//     <div
//       key={`${row}-${col}`}    
//       className={`square ${blackSq ? "black" : "white"}`}
//     />
//   );
// }
// squares.push(
//   <div key={row} className='row'>
//   {squares}
//   </div>
// );
// }

// return <div className="ChessBoard">{board}</div>

// };

// export default ChessBoard
